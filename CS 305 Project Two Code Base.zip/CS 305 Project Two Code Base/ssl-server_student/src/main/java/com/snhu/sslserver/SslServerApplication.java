package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {
    
    // Converts byte array to hex string
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
    

    @RequestMapping("/hash")
    public String myHash() {
        // Your unique data string
        String data = "My name is MAX MR THE PROGRAMMER"; 
        try {
            // Create a SHA-256 digest
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
            // Apply the digest algorithm to your data string
            byte[] encodedhash = digest.digest(data.getBytes());

            // Convert the hash value to hex
            String hexChecksum = bytesToHex(encodedhash);
            
            // Returning the data, cipher algorithm used, and checksum value
            return String.format("<p>data: %s</p><p>Name of Cipher Algorithm Used: SHA-256</p><p>Checksum Value: %s</p>", data, hexChecksum);
        } catch (NoSuchAlgorithmException e) {
            return "Algorithm not found: " + e.getMessage();
        }
    }
}